#include "hardware.h"
#include "config.h"

void initSensor();
float readTemperature();

void initDisplay();
void showStatus(float temp, bool alarm);

void handleAlarm(bool alarm);

void initButtons();
void handleButtons();

extern float setTemp;

void setup() {

  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(FAN_PIN, OUTPUT);

  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, LOW);
  digitalWrite(BUZZER, LOW);
  digitalWrite(FAN_PIN, LOW);

  initSensor();     
  initDisplay();    
  initButtons();    
}

void loop() {

  handleButtons();

  float temp = readTemperature();
  if (temp < -100) return;  

  bool alarm = (temp > setTemp);

  handleAlarm(alarm);

  showStatus(temp, alarm);
}
