#include "hardware.h"


bool buzzerDone = false;
unsigned long lastFlashTime = 0;
bool redLedState = false;

void handleAlarm(bool alarm) {

  unsigned long now = millis();

  if (alarm) {
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(FAN_PIN, HIGH);

    if (!buzzerDone) {
      static int beepCount = 0;
      static unsigned long lastBeepTime = 0;

      if (beepCount < 6 && now - lastBeepTime >= 200) {
        lastBeepTime = now;
        digitalWrite(BUZZER, !digitalRead(BUZZER));
        beepCount++;
      }

      if (beepCount >= 6) {
        digitalWrite(BUZZER, LOW);
        buzzerDone = true;
        beepCount = 0;
      }
    }

    if (now - lastFlashTime >= 300) {
      lastFlashTime = now;
      redLedState = !redLedState;
      digitalWrite(RED_LED, redLedState);
    }
  }
  else {
    digitalWrite(RED_LED, LOW);
    digitalWrite(GREEN_LED, HIGH);
    digitalWrite(BUZZER, LOW);
    digitalWrite(FAN_PIN, LOW);

    buzzerDone = false;
    redLedState = false;
  }
}
