#include "hardware.h"

float setTemp = 26.0;
unsigned long lastButtonTime = 0;

void initButtons() {
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
}

void handleButtons() {

  if (digitalRead(BTN_UP) == LOW) {
    setTemp += 0.5;
    if (setTemp > 35.0) setTemp = 35.0;
    lastButtonTime = millis();
    delay(250); // debounce
  }

  if (digitalRead(BTN_DOWN) == LOW) {
    setTemp -= 0.5;
    if (setTemp < 18.0) setTemp = 18.0;
    lastButtonTime = millis();
    delay(250); // debounce
  }
}
