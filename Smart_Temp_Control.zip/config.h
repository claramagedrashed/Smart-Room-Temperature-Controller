#ifndef CONFIG_H
#define CONFIG_H

#define TEMP_LIMIT 26.0

#endif
