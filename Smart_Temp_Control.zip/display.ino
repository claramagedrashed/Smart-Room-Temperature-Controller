#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

extern float setTemp;
extern unsigned long lastButtonTime;

String lastLine1 = "";
String lastLine2 = "";

void initDisplay() {
  lcd.init();
  lcd.backlight();
  lcd.clear();
}

void showStatus(float temp, bool alarm) {

  String line1;
  String line2;

  line1 = "Temp: " + String(temp, 1) + " C";

  if (millis() - lastButtonTime < 4000) {
    line2 = "Set Temp: " + String(setTemp, 1);
  }
  else if (alarm) {
    line2 = "Warning: HOT";
  }
  else {
    line2 = "Temp: Neutral";
  }

  if (line1 != lastLine1) {
    lcd.setCursor(0, 0);
    lcd.print("                "); 
    lcd.setCursor(0, 0);
    lcd.print(line1);
    lastLine1 = line1;
  }

  if (line2 != lastLine2) {
    lcd.setCursor(0, 1);
    lcd.print("                "); 
    lcd.setCursor(0, 1);
    lcd.print(line2);
    lastLine2 = line2;
  }
}
