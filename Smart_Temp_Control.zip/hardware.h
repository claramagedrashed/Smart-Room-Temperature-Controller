#ifndef HARDWARE_H
#define HARDWARE_H
#define BTN_UP     4
#define BTN_DOWN   5

#define DHTPIN 2
#define DHTTYPE DHT22

#define RED_LED     8
#define GREEN_LED   6
#define BUZZER      7
#define FAN_PIN     9

#endif
