#include <DHT.h>
#include "hardware.h"

DHT dht(DHTPIN, DHTTYPE);

void initSensor() {
  dht.begin();
}

float readTemperature() {
  float t = dht.readTemperature();
  if (isnan(t)) return -1000.0;
  return t;
}
